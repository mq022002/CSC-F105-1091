
public class LoopPractice {

	public static void main(String[] args) {

		int sum = 0; int count = 3;

		while (count <= 213){
			sum = sum + count;
			count += 3; ///count = count + 3
		}
		System.out.println(sum);
	}
}
