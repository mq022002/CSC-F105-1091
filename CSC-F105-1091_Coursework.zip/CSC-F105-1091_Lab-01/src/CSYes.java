
public class CSYes {

	public static void main(String[] args)
	{
		// -------------------------------------------------
		// The following main method prints an exciting
		// message about computer science
		// --
		System.out.println("Computer Science, Yes!!!!");
		System.out.println("=========================");
	}

}
