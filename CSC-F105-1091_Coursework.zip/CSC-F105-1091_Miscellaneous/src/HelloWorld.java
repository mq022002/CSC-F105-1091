//import java.util.Random;
//import java.util.Scanner;

public class HelloWorld {

	public static void main(String[] args)
	{
		// The following code prints the line "Hello World" in the console below.
//		System.out.println("Hello World!");
//		System.out.println(3/0);
		// The following comment means that a method has automatically been generated for me, but the body of code was left blank for me to fill in myself.
		// TODO Auto-generated method stub

//		System.out.print("MxCC"); //MxCC, new line character at the end
//		System.out.println("100 Training Hill Rd");//100 Training Hill Rd there is no new line character at the end
//		System.out.print("Middletown, CT 06457");//Middletown, CT 06457 at the same line as before, and there is a

//		System.out.println("1");
//		System.out.print("2");
//		System.out.println("3");
//		System.out.println("4");
//		System.out.print("5");
//		System.out.println();
//		System.out.println();
//		System.out.print("6");
//		System.out.println("7");
//		System.out.print("8");
//		System.out.println("9");
//		System.out.print("10");
//		System.out.print("1 ");
//		System.out.print("2 ");
//		System.out.println();
//		System.out.println("3 ");

		// Print out 3 lines using one System.out.println method

//		System.out.println("\"Thank you all for "
//				+ "coming to my home\n\t tonight,\" he said"
//				+ "mysteriously.");
//		System.out.println("\"I made this letter longer than usual because  "
//				+ "\n I lack the time to make it short.\"\n\t Blaise Pascal");

//		int a = 100; //declare an integer variable, named total
//		System.out.println(a);
//		int a = 50; //can't declare the same variable twice
//		int b = 50;
//		int c = a+b;
//		System.out.println(c);

//		int a = 10;
//		int b = 20;
//		final int HEIGHT = 200;
//
//		System.out.println(HEIGHT);
//
//		b = 50;
//
//		System.out.println(a);
//		System.out.println(b);
//		int c = a+b;
//		System.out.println(c);

//		System.out.println("\"I made this letter longer than "
//				+ "usual because I lack the time to make it "
//				+ "short.\"\nBlaise Pascal");
//
//		byte d = 20;
//		short e = 1000;
//		int f = 49383;
//		long g = 23049820;
//		float h = 3.5f; //note: add a f at the end
//		double i = 23424.4564646;
//		char j = 'j';
//
//		System.out.println(d+"\t"+e+"\t"+f+"\t"+g);
//		System.out.println(h+"\t"+i);
//		System.out.println(j);

//		int count = 5;
//		count++; //count = count+1;
//		System.out.println(count);
//
//		int x = 10;
//		int y = 20;
//		x+=y;
//		System.out.println(x);
//		System.out.println(y);

//		int x = 90;
//		int y = 89;
//		int z = 87;
//		int answer = (x + y + z) / 3;
//		System.out.println("Answer: " + answer);

//		Scanner scan = new Scanner(System.in);
//		Random generator = new Random();
//		int num;
//		// Scanner is a class, located in java.util package, and scan is an object, named by programmer
//		// New means that each time when you create an object, you need to call the constructor of the class
//		// System.class in means that you will take the input from the keyboard.
//
//		System.out.println("What is your first name? ");
//		String fname = scan.nextLine();
//		
//		System.out.println("What is your last name? ");
//		String lname = scan.nextLine();
//		
//		num = generator.nextInt(500) + 500;
//		
//		System.out.println(lname.charAt(0) + fname.substring(0,3) + num + "@mail.ct.edu");

//		int value = 5;
//		for (int num = 1; num < value; num++)
//		{
//		for (int i = 1; i < (value - num); i++)
//		System.out.print(" ");
//		for (int i = 1; i < ((3 * num) - 1); i++)
//		System.out.print("*");
//		System.out.println();
//		}
		
//		int low = 10, high = 18;
//		do
//		{
//		System.out.println(low);
//		low++;
//		} while (low < high);
		
//        int value1 = 10;
//        int value2 = 5;
//        boolean done = false;
//        if(value1 <= value2)
//            System.out.println("a.True");
//        
//        if((value1 + 5) >= value2)
//            System.out.println("b.True");
//        
//        if(value1 < value2 / 2)
//            System.out.println("c.True");
//        
//        if(value2 != value1)
//            System.out.println("d.True");
//        
//        if(!(value1 == value2))
//            System.out.println("e.True");
//        
//        if((value1 < value2) || done)
//            System.out.println("f.True");
//        
//        if((value1 > value2) || done)
//            System.out.println("g.True");
//        
//        if((value1 < value2) && done)
//            System.out.println("h.True");
//        
//        if(done || !done)
//            System.out.println("i.True");
//        
//        if(((value1 > value2) || done) && (!done || (value2 > value1)))
//            System.out.println("j.True");
        
//		int num1 = 7;
//		int num2 = 15;
//		if (num1 >= num2)
//		{
//			System.out.print(" red ");
//			System.out.print(" orange ");
//		}
//		if ((num1 + 5) >= num2)
//			System.out.print(" white ");
//		else
//			if ((num1 + 10) >= num2)
//			{
//				System.out.print(" black ");
//				System.out.print(" blue ");
//		}
//		else
//			System.out.print(" yellow ");
//		 System.out.print(" green ");
		
		//prompt the user for their name
//		System.out.println("What is your name? ");
//		String name = scan.nextLine();
//
//		System.out.println("Please enter 3 test scores: "); //prompt the user regarding the input
//		int grade1 = scan.nextInt();
//		int grade2 = scan.nextInt();
//		int grade3 = scan.nextInt();
//
//		double average = (grade1 + grade2 + grade3)/3.0;
//		System.out.println(name + " your average is: " + average);
		
//		System.out.println("Enter a number: ");
//		double number = scan.nextDouble();
//		double value = ((number*number)+5);
//		System.out.printf("%.2f", value);
		
//		int result = 20;
//		result = result + 3;
//		System.out.println(result);
//		result = result / 7;
//		System.out.println(result);
//		result = result * 2;
//		System.out.println(result);
		
//		int iResult, num1 = 34, num2 = 5;
//		double fResult, val1 = 11.0, val2 = 2.34;
//		
//		iResult = num1 / num2;
//		System.out.println(iResult);
//		
//		fResult = num1 / num2;
//		System.out.println(fResult);
//		
//		fResult = val1 / num2;
//		System.out.println(fResult);
//		
//		fResult = (double) num1 / num2;
//		System.out.println(fResult);
//		
//		iResult = (int) val2 / num2;
//		System.out.println(iResult);
		
//		String s1 = "Foundations";
//		String s2;
//		System.out.println(s1.charAt(3));
//		s2 = s1.substring(1, 5);
//		System.out.println(s2);
//		System.out.println(s1.length());
//		System.out.println(s2.length());
				
	}

}